from django.contrib.auth import views as auth_views
from django.urls import path
from . import views
from .login_seguro import LoginSeguroView

urlpatterns = [
    path('', views.redirigir_por_rol, name='redirigir_por_rol'),
    path('login/', LoginSeguroView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('privacidad/', views.aviso_privacidad, name='aviso_privacidad'),
    path('privacidad/consentimiento/', views.consentimiento, name='consentimiento'),
]